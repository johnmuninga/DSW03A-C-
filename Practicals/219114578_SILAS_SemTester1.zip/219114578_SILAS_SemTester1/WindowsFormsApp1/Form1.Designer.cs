﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbBig = new System.Windows.Forms.Label();
            this.lbNum = new System.Windows.Forms.Label();
            this.lbName = new System.Windows.Forms.Label();
            this.lbSur = new System.Windows.Forms.Label();
            this.lbEmail = new System.Windows.Forms.Label();
            this.lbAdd = new System.Windows.Forms.Label();
            this.textNum = new System.Windows.Forms.TextBox();
            this.textName = new System.Windows.Forms.TextBox();
            this.textSur = new System.Windows.Forms.TextBox();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.textIP = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.rdFemale = new System.Windows.Forms.RadioButton();
            this.rdMale = new System.Windows.Forms.RadioButton();
            this.rdCom = new System.Windows.Forms.RadioButton();
            this.rdGov = new System.Windows.Forms.RadioButton();
            this.rdEdu = new System.Windows.Forms.RadioButton();
            this.rdRu = new System.Windows.Forms.RadioButton();
            this.rdUk = new System.Windows.Forms.RadioButton();
            this.rdJp = new System.Windows.Forms.RadioButton();
            this.lbDomain = new System.Windows.Forms.Label();
            this.lbLoad = new System.Windows.Forms.Button();
            this.btPre = new System.Windows.Forms.Button();
            this.lbDiez = new System.Windows.Forms.Label();
            this.lbName2 = new System.Windows.Forms.Label();
            this.lbSur2 = new System.Windows.Forms.Label();
            this.lbEmail2 = new System.Windows.Forms.Label();
            this.lbGender2 = new System.Windows.Forms.Label();
            this.lbIP = new System.Windows.Forms.Label();
            this.btNext = new System.Windows.Forms.Button();
            this.grpGender = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpGender.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(141, 125);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lbBig
            // 
            this.lbBig.AutoSize = true;
            this.lbBig.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBig.Location = new System.Drawing.Point(364, 57);
            this.lbBig.Name = "lbBig";
            this.lbBig.Size = new System.Drawing.Size(148, 37);
            this.lbBig.TabIndex = 1;
            this.lbBig.Text = "Big Data";
            // 
            // lbNum
            // 
            this.lbNum.AutoSize = true;
            this.lbNum.Location = new System.Drawing.Point(12, 157);
            this.lbNum.Name = "lbNum";
            this.lbNum.Size = new System.Drawing.Size(44, 13);
            this.lbNum.TabIndex = 2;
            this.lbNum.Text = "Number";
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.Location = new System.Drawing.Point(12, 196);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(35, 13);
            this.lbName.TabIndex = 3;
            this.lbName.Text = "Name";
            // 
            // lbSur
            // 
            this.lbSur.AutoSize = true;
            this.lbSur.Location = new System.Drawing.Point(9, 234);
            this.lbSur.Name = "lbSur";
            this.lbSur.Size = new System.Drawing.Size(49, 13);
            this.lbSur.TabIndex = 4;
            this.lbSur.Text = "Surname";
            // 
            // lbEmail
            // 
            this.lbEmail.AutoSize = true;
            this.lbEmail.Location = new System.Drawing.Point(9, 270);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(32, 13);
            this.lbEmail.TabIndex = 5;
            this.lbEmail.Text = "Email";
            // 
            // lbAdd
            // 
            this.lbAdd.AutoSize = true;
            this.lbAdd.Location = new System.Drawing.Point(9, 310);
            this.lbAdd.Name = "lbAdd";
            this.lbAdd.Size = new System.Drawing.Size(58, 13);
            this.lbAdd.TabIndex = 6;
            this.lbAdd.Text = "IP Address";
            // 
            // textNum
            // 
            this.textNum.Location = new System.Drawing.Point(99, 154);
            this.textNum.Name = "textNum";
            this.textNum.Size = new System.Drawing.Size(129, 20);
            this.textNum.TabIndex = 7;
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(99, 193);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(129, 20);
            this.textName.TabIndex = 8;
            // 
            // textSur
            // 
            this.textSur.Location = new System.Drawing.Point(99, 234);
            this.textSur.Name = "textSur";
            this.textSur.Size = new System.Drawing.Size(129, 20);
            this.textSur.TabIndex = 9;
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(99, 267);
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(129, 20);
            this.textEmail.TabIndex = 10;
            // 
            // textIP
            // 
            this.textIP.Location = new System.Drawing.Point(99, 307);
            this.textIP.Name = "textIP";
            this.textIP.Size = new System.Drawing.Size(129, 20);
            this.textIP.TabIndex = 11;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 388);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(697, 82);
            this.listBox1.TabIndex = 12;
            // 
            // rdFemale
            // 
            this.rdFemale.AutoSize = true;
            this.rdFemale.Location = new System.Drawing.Point(0, 18);
            this.rdFemale.Name = "rdFemale";
            this.rdFemale.Size = new System.Drawing.Size(59, 17);
            this.rdFemale.TabIndex = 14;
            this.rdFemale.TabStop = true;
            this.rdFemale.Text = "Female";
            this.rdFemale.UseVisualStyleBackColor = true;
            // 
            // rdMale
            // 
            this.rdMale.AutoSize = true;
            this.rdMale.Location = new System.Drawing.Point(129, 18);
            this.rdMale.Name = "rdMale";
            this.rdMale.Size = new System.Drawing.Size(48, 17);
            this.rdMale.TabIndex = 15;
            this.rdMale.TabStop = true;
            this.rdMale.Text = "Male";
            this.rdMale.UseVisualStyleBackColor = true;
            // 
            // rdCom
            // 
            this.rdCom.AutoSize = true;
            this.rdCom.Location = new System.Drawing.Point(12, 489);
            this.rdCom.Name = "rdCom";
            this.rdCom.Size = new System.Drawing.Size(48, 17);
            this.rdCom.TabIndex = 16;
            this.rdCom.TabStop = true;
            this.rdCom.Text = ".com";
            this.rdCom.UseVisualStyleBackColor = true;
            this.rdCom.CheckedChanged += new System.EventHandler(this.rdCom_CheckedChanged);
            // 
            // rdGov
            // 
            this.rdGov.AutoSize = true;
            this.rdGov.Location = new System.Drawing.Point(143, 489);
            this.rdGov.Name = "rdGov";
            this.rdGov.Size = new System.Drawing.Size(46, 17);
            this.rdGov.TabIndex = 17;
            this.rdGov.TabStop = true;
            this.rdGov.Text = ".gov";
            this.rdGov.UseVisualStyleBackColor = true;
            this.rdGov.CheckedChanged += new System.EventHandler(this.rdGov_CheckedChanged);
            // 
            // rdEdu
            // 
            this.rdEdu.AutoSize = true;
            this.rdEdu.Location = new System.Drawing.Point(266, 489);
            this.rdEdu.Name = "rdEdu";
            this.rdEdu.Size = new System.Drawing.Size(46, 17);
            this.rdEdu.TabIndex = 18;
            this.rdEdu.TabStop = true;
            this.rdEdu.Text = ".edu";
            this.rdEdu.UseVisualStyleBackColor = true;
            this.rdEdu.CheckedChanged += new System.EventHandler(this.rdEdu_CheckedChanged);
            // 
            // rdRu
            // 
            this.rdRu.AutoSize = true;
            this.rdRu.Location = new System.Drawing.Point(395, 489);
            this.rdRu.Name = "rdRu";
            this.rdRu.Size = new System.Drawing.Size(37, 17);
            this.rdRu.TabIndex = 19;
            this.rdRu.TabStop = true;
            this.rdRu.Text = ".ru";
            this.rdRu.UseVisualStyleBackColor = true;
            this.rdRu.CheckedChanged += new System.EventHandler(this.rdRu_CheckedChanged);
            // 
            // rdUk
            // 
            this.rdUk.AutoSize = true;
            this.rdUk.Location = new System.Drawing.Point(510, 489);
            this.rdUk.Name = "rdUk";
            this.rdUk.Size = new System.Drawing.Size(40, 17);
            this.rdUk.TabIndex = 20;
            this.rdUk.TabStop = true;
            this.rdUk.Text = ".uk";
            this.rdUk.UseVisualStyleBackColor = true;
            this.rdUk.CheckedChanged += new System.EventHandler(this.rdUk_CheckedChanged);
            // 
            // rdJp
            // 
            this.rdJp.AutoSize = true;
            this.rdJp.Location = new System.Drawing.Point(615, 489);
            this.rdJp.Name = "rdJp";
            this.rdJp.Size = new System.Drawing.Size(36, 17);
            this.rdJp.TabIndex = 21;
            this.rdJp.TabStop = true;
            this.rdJp.Text = ".jp";
            this.rdJp.UseVisualStyleBackColor = true;
            this.rdJp.CheckedChanged += new System.EventHandler(this.rdJp_CheckedChanged);
            // 
            // lbDomain
            // 
            this.lbDomain.AutoSize = true;
            this.lbDomain.Location = new System.Drawing.Point(12, 473);
            this.lbDomain.Name = "lbDomain";
            this.lbDomain.Size = new System.Drawing.Size(43, 13);
            this.lbDomain.TabIndex = 22;
            this.lbDomain.Text = "Domain";
            // 
            // lbLoad
            // 
            this.lbLoad.Location = new System.Drawing.Point(457, 256);
            this.lbLoad.Name = "lbLoad";
            this.lbLoad.Size = new System.Drawing.Size(64, 23);
            this.lbLoad.TabIndex = 23;
            this.lbLoad.Text = "Load";
            this.lbLoad.UseVisualStyleBackColor = true;
            this.lbLoad.Click += new System.EventHandler(this.lbLoad_Click);
            // 
            // btPre
            // 
            this.btPre.Location = new System.Drawing.Point(615, 256);
            this.btPre.Name = "btPre";
            this.btPre.Size = new System.Drawing.Size(64, 23);
            this.btPre.TabIndex = 25;
            this.btPre.Text = "<";
            this.btPre.UseVisualStyleBackColor = true;
            this.btPre.Click += new System.EventHandler(this.btPre_Click);
            // 
            // lbDiez
            // 
            this.lbDiez.AutoSize = true;
            this.lbDiez.Location = new System.Drawing.Point(12, 372);
            this.lbDiez.Name = "lbDiez";
            this.lbDiez.Size = new System.Drawing.Size(14, 13);
            this.lbDiez.TabIndex = 26;
            this.lbDiez.Text = "#";
            this.lbDiez.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbName2
            // 
            this.lbName2.AutoSize = true;
            this.lbName2.Location = new System.Drawing.Point(96, 372);
            this.lbName2.Name = "lbName2";
            this.lbName2.Size = new System.Drawing.Size(35, 13);
            this.lbName2.TabIndex = 27;
            this.lbName2.Text = "Name";
            // 
            // lbSur2
            // 
            this.lbSur2.AutoSize = true;
            this.lbSur2.Location = new System.Drawing.Point(221, 372);
            this.lbSur2.Name = "lbSur2";
            this.lbSur2.Size = new System.Drawing.Size(49, 13);
            this.lbSur2.TabIndex = 28;
            this.lbSur2.Text = "Surname";
            // 
            // lbEmail2
            // 
            this.lbEmail2.AutoSize = true;
            this.lbEmail2.Location = new System.Drawing.Point(352, 372);
            this.lbEmail2.Name = "lbEmail2";
            this.lbEmail2.Size = new System.Drawing.Size(32, 13);
            this.lbEmail2.TabIndex = 29;
            this.lbEmail2.Text = "Email";
            // 
            // lbGender2
            // 
            this.lbGender2.AutoSize = true;
            this.lbGender2.Location = new System.Drawing.Point(507, 372);
            this.lbGender2.Name = "lbGender2";
            this.lbGender2.Size = new System.Drawing.Size(42, 13);
            this.lbGender2.TabIndex = 30;
            this.lbGender2.Text = "Gender";
            // 
            // lbIP
            // 
            this.lbIP.AutoSize = true;
            this.lbIP.Location = new System.Drawing.Point(651, 372);
            this.lbIP.Name = "lbIP";
            this.lbIP.Size = new System.Drawing.Size(58, 13);
            this.lbIP.TabIndex = 31;
            this.lbIP.Text = "IP Address";
            // 
            // btNext
            // 
            this.btNext.Location = new System.Drawing.Point(531, 256);
            this.btNext.Name = "btNext";
            this.btNext.Size = new System.Drawing.Size(64, 23);
            this.btNext.TabIndex = 24;
            this.btNext.Text = ">";
            this.btNext.UseVisualStyleBackColor = true;
            this.btNext.Click += new System.EventHandler(this.btNext_Click);
            // 
            // grpGender
            // 
            this.grpGender.Controls.Add(this.rdFemale);
            this.grpGender.Controls.Add(this.rdMale);
            this.grpGender.Location = new System.Drawing.Point(457, 193);
            this.grpGender.Name = "grpGender";
            this.grpGender.Size = new System.Drawing.Size(222, 48);
            this.grpGender.TabIndex = 32;
            this.grpGender.TabStop = false;
            this.grpGender.Text = "Gender";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 518);
            this.Controls.Add(this.grpGender);
            this.Controls.Add(this.lbIP);
            this.Controls.Add(this.lbGender2);
            this.Controls.Add(this.lbEmail2);
            this.Controls.Add(this.lbSur2);
            this.Controls.Add(this.lbName2);
            this.Controls.Add(this.lbDiez);
            this.Controls.Add(this.btPre);
            this.Controls.Add(this.btNext);
            this.Controls.Add(this.lbLoad);
            this.Controls.Add(this.lbDomain);
            this.Controls.Add(this.rdJp);
            this.Controls.Add(this.rdUk);
            this.Controls.Add(this.rdRu);
            this.Controls.Add(this.rdEdu);
            this.Controls.Add(this.rdGov);
            this.Controls.Add(this.rdCom);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textIP);
            this.Controls.Add(this.textEmail);
            this.Controls.Add(this.textSur);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.textNum);
            this.Controls.Add(this.lbAdd);
            this.Controls.Add(this.lbEmail);
            this.Controls.Add(this.lbSur);
            this.Controls.Add(this.lbName);
            this.Controls.Add(this.lbNum);
            this.Controls.Add(this.lbBig);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpGender.ResumeLayout(false);
            this.grpGender.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbBig;
        private System.Windows.Forms.Label lbNum;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.Label lbSur;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.Label lbAdd;
        private System.Windows.Forms.TextBox textNum;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textSur;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.TextBox textIP;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.RadioButton rdFemale;
        private System.Windows.Forms.RadioButton rdMale;
        private System.Windows.Forms.RadioButton rdCom;
        private System.Windows.Forms.RadioButton rdGov;
        private System.Windows.Forms.RadioButton rdEdu;
        private System.Windows.Forms.RadioButton rdRu;
        private System.Windows.Forms.RadioButton rdUk;
        private System.Windows.Forms.RadioButton rdJp;
        private System.Windows.Forms.Label lbDomain;
        private System.Windows.Forms.Button lbLoad;
        private System.Windows.Forms.Button btPre;
        private System.Windows.Forms.Label lbDiez;
        private System.Windows.Forms.Label lbName2;
        private System.Windows.Forms.Label lbSur2;
        private System.Windows.Forms.Label lbEmail2;
        private System.Windows.Forms.Label lbGender2;
        private System.Windows.Forms.Label lbIP;
        private System.Windows.Forms.Button btNext;
        private System.Windows.Forms.GroupBox grpGender;
    }
}

