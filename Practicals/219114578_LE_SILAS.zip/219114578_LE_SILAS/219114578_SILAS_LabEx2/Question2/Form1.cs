﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UJExamPortalSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            string studNum = txtStuNum.Text;
            int assignment = Convert.ToInt32(txtExam.Text);
            int test = Convert.ToInt32(txtTest.Text);
            int exam = Convert.ToInt32(txtAssignment.Text);
            StudentClass studentClass = new StudentClass(studNum, test, exam, assignment);
            calculationOfMark(studentClass.studentAssignmentMark, studentClass.studentTestMark, studentClass.studentExamMark);
            btnDisplay.Enabled = true;
            btnWrite.Enabled = true;
            btnCompute.Enabled = false;
        }
        public string calculationOfMark(double stuMarkAss,double stuMarkTest, double stuMarkExam )
        {
            return txtFinal.Text = (((stuMarkAss * 20) / 100) + ((stuMarkTest * 30) / 100) + ((stuMarkExam * 50) / 100)).ToString();
        }

        public string checkMark(string displayCheckMark)
        {
            if ((Convert.ToInt32(txtFinal.Text)) >= 50)
            {
                displayCheckMark = "Pass";
            }
            else
            {
                displayCheckMark = "Fail";
            }
            return displayCheckMark;
        }


        //Add button
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string studNum = txtStuNum.Text;
            int assignment = Convert.ToInt32(txtExam.Text);
            int test = Convert.ToInt32(txtTest.Text);
            int exam = Convert.ToInt32(txtAssignment.Text);
            StudentClass studentClass = new StudentClass(studNum, test, exam, assignment);
            calculationOfMark(studentClass.studentAssignmentMark, studentClass.studentTestMark, studentClass.studentExamMark);
            checkMark(calculationOfMark(studentClass.studentAssignmentMark, studentClass.studentTestMark, studentClass.studentExamMark));
            MessageBox.Show("Record 1 has been added to the list");
            btnDisplay.Enabled = true;

        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            string dataset = "./exam.txt";

            string studNum = txtStuNum.Text;
            int assignment = Convert.ToInt32(txtExam.Text);

            int test = Convert.ToInt32(txtTest.Text);

            int exam = Convert.ToInt32(txtAssignment.Text);

            StudentClass studentClass = new StudentClass(studNum, test, exam, assignment);

            calculationOfMark(studentClass.studentAssignmentMark, studentClass.studentTestMark, studentClass.studentExamMark);

            checkMark(calculationOfMark(studentClass.studentAssignmentMark, studentClass.studentTestMark, studentClass.studentExamMark));
            MessageBox.Show("One record has been added to the file");

            string studentRecord =  $"\n{studNum}, \t \t {txtFinal.Text}, \t \t {checkMark(calculationOfMark(studentClass.studentAssignmentMark, studentClass.studentTestMark, studentClass.studentExamMark))}";
            List<string> allMyDataSet = new List<string>();
            File.AppendAllText(dataset, studentRecord);
            btnWrite.Enabled = false;
            btnDisplay.Enabled = true;
            btnCompute.Enabled = true; 
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            string dataset = "./exam.txt";
            List<string> allMyDataSet = new List<string>();
            using (var reader = new StreamReader(dataset))
            {
                while (!reader.EndOfStream)
                {
                    string lines = reader.ReadLine();
                    allMyDataSet.Add(lines);
                    listBox1.Items.Add($"{lines}\n");
                }
            }

            btnDisplay.Enabled = false;
            btnWrite.Enabled = true;
            btnCompute.Enabled = true;

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtExam.Clear();
            txtAssignment.Clear();
            txtFinal.Clear();
            txtStuNum.Clear();
            txtTest.Clear();
            listBox1.Items.Clear();
            btnAdd.Enabled = true;
            btnCompute.Enabled = true;
            btnDisplay.Enabled = true;
            btnWrite.Enabled = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
